// ============================================
// Word of the Day - Enhanced Extension v2.0
// ============================================

// State
let currentWord = null;
let stats = {
  currentStreak: 0,
  bestStreak: 0,
  wordsLearned: 0,
  learnedWords: [],
  skippedWords: [],
  favorites: [],
  lastPracticeDate: null,
  difficulty: 2,
  theme: 'light',
  notificationsEnabled: false,
  soundEnabled: true,
  isFirstTime: true,
  spacedRepetition: [],
  learningHistory: {},
  enabledCategories: ['general', 'business', 'literature', 'science', 'philosophy', 'law', 'medicine', 'arts'],
  wordMastery: {}, // { "word": { level: 1-5, lastSeen: date, correctCount: n } }
  personalNotes: {}, // { "word": "note text" }
  wordHistory: [], // [{ word, date, action }]
  streakFreezeUsed: null,
  streakFreezeWeek: null,
  // v3.0 New Features
  pronunciationSpeed: 0.8, // 0.5, 0.75, 1.0
  collections: { favorites: [] }, // Named collections
  dailyGoal: 1, // 1, 2, or 3 words per day
  todayWordsLearned: 0,
  lastGoalDate: null,
  xp: 0,
  level: 1,
  achievements: [], // Unlocked achievement IDs
  dailyChallengeCompleted: null, // Date string
  customWords: [], // User-imported words
  quizHistory: [], // { date, score, total }
  missedDays: 0 // For streak recovery
};
let quizState = { questions: [], current: 0, score: 0 };
let challengeState = { mode: null, questions: [], current: 0, score: 0, startTime: null, timer: null };

// Achievement definitions
const ACHIEVEMENTS = [
  { id: 'first_word', name: 'First Steps', icon: '🌱', desc: 'Learn your first word', xp: 10 },
  { id: 'streak_7', name: 'On Fire', icon: '🔥', desc: '7 day streak', xp: 50 },
  { id: 'streak_30', name: 'Unstoppable', icon: '💪', desc: '30 day streak', xp: 200 },
  { id: 'streak_100', name: 'Legendary', icon: '👑', desc: '100 day streak', xp: 500 },
  { id: 'words_10', name: 'Getting Started', icon: '📖', desc: 'Learn 10 words', xp: 25 },
  { id: 'words_50', name: 'Word Collector', icon: '📚', desc: 'Learn 50 words', xp: 100 },
  { id: 'words_100', name: 'Scholar', icon: '🎓', desc: 'Learn 100 words', xp: 250 },
  { id: 'words_200', name: 'Lexicon Master', icon: '🏆', desc: 'Learn 200 words', xp: 500 },
  { id: 'early_bird', name: 'Early Bird', icon: '🌅', desc: 'Learn before 8 AM', xp: 30 },
  { id: 'night_owl', name: 'Night Owl', icon: '🦉', desc: 'Learn after 10 PM', xp: 30 },
  { id: 'perfect_quiz', name: 'Perfect Score', icon: '💯', desc: 'Get 100% on a quiz', xp: 50 },
  { id: 'quiz_streak_5', name: 'Quiz Master', icon: '🎯', desc: '5 perfect quizzes in a row', xp: 150 },
  { id: 'speed_demon', name: 'Speed Demon', icon: '⚡', desc: 'Perfect speed challenge', xp: 75 },
  { id: 'all_categories', name: 'Renaissance', icon: '🎨', desc: 'Learn from all 8 categories', xp: 100 },
  { id: 'mastery_5', name: 'Word Master', icon: '⭐', desc: 'Master 5 words (5 stars)', xp: 75 },
  { id: 'mastery_20', name: 'Vocabulary Sage', icon: '🔮', desc: 'Master 20 words', xp: 200 },
  { id: 'recovery', name: 'Comeback Kid', icon: '🔄', desc: 'Recover a broken streak', xp: 40 },
  { id: 'goal_week', name: 'Goal Getter', icon: '🎯', desc: 'Hit daily goal for 7 days', xp: 100 },
  { id: 'challenge_all', name: 'Challenger', icon: '🏅', desc: 'Complete all 3 challenge types', xp: 75 },
  { id: 'notes_10', name: 'Note Taker', icon: '📝', desc: 'Add notes to 10 words', xp: 50 }
];

// XP Level thresholds
const LEVELS = [
  { level: 1, name: 'Novice', minXP: 0 },
  { level: 2, name: 'Apprentice', minXP: 100 },
  { level: 3, name: 'Student', minXP: 300 },
  { level: 4, name: 'Scholar', minXP: 600 },
  { level: 5, name: 'Expert', minXP: 1000 },
  { level: 6, name: 'Master', minXP: 1500 },
  { level: 7, name: 'Wordsmith', minXP: 2500 },
  { level: 8, name: 'Lexicon Sage', minXP: 4000 },
  { level: 9, name: 'Vocabulary Virtuoso', minXP: 6000 },
  { level: 10, name: 'Word Wizard', minXP: 10000 }
];

// Daily challenges
const DAILY_CHALLENGES = [
  { id: 'learn_2', desc: 'Learn 2 words today', check: (s) => s.todayWordsLearned >= 2, xp: 20 },
  { id: 'perfect_quiz', desc: 'Get a perfect quiz score', check: (s, extra) => extra?.perfectQuiz, xp: 30 },
  { id: 'new_category', desc: 'Learn a word from a new category', check: (s, extra) => extra?.newCategory, xp: 25 },
  { id: 'use_hint', desc: 'Use the hint feature', check: (s, extra) => extra?.usedHint, xp: 10 },
  { id: 'add_note', desc: 'Add a personal note to a word', check: (s, extra) => extra?.addedNote, xp: 15 },
  { id: 'speed_challenge', desc: 'Complete a speed challenge', check: (s, extra) => extra?.speedChallenge, xp: 25 },
  { id: 'review_old', desc: 'Review a word from last week', check: (s, extra) => extra?.reviewedOld, xp: 20 }
];

// Audio context for sounds
let audioCtx = null;

// ============================================
// Initialization
// ============================================

document.addEventListener('DOMContentLoaded', async () => {
  await loadStats();
  applyTheme(stats.theme);
  updateDate();
  initAudio();
  
  await checkLookupWord();
  
  if (stats.isFirstTime) {
    showOnboarding();
  }
  
  checkStreakFreeze();
  checkDailyGoal();
  await loadOrSetDailyWord();
  updateUI();
  setupEventListeners();
  setupKeyboardShortcuts();
  checkSpacedRepetition();
  generateCategoryToggles();
  updateSoundIcon();
  updateLevelDisplay();
  updateGoalDisplay();
  updateDailyChallengeDisplay();
  checkAchievements();
});

// ============================================
// Audio / Sound Effects
// ============================================

function initAudio() {
  audioCtx = new (window.AudioContext || window.webkitAudioContext)();
}

function playSound(type) {
  if (!stats.soundEnabled || !audioCtx) return;
  
  const oscillator = audioCtx.createOscillator();
  const gainNode = audioCtx.createGain();
  
  oscillator.connect(gainNode);
  gainNode.connect(audioCtx.destination);
  
  switch(type) {
    case 'success':
      oscillator.frequency.setValueAtTime(523.25, audioCtx.currentTime); // C5
      oscillator.frequency.setValueAtTime(659.25, audioCtx.currentTime + 0.1); // E5
      oscillator.frequency.setValueAtTime(783.99, audioCtx.currentTime + 0.2); // G5
      gainNode.gain.setValueAtTime(0.3, audioCtx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.4);
      oscillator.start(audioCtx.currentTime);
      oscillator.stop(audioCtx.currentTime + 0.4);
      break;
    case 'error':
      oscillator.frequency.setValueAtTime(200, audioCtx.currentTime);
      oscillator.frequency.setValueAtTime(150, audioCtx.currentTime + 0.1);
      gainNode.gain.setValueAtTime(0.3, audioCtx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.2);
      oscillator.start(audioCtx.currentTime);
      oscillator.stop(audioCtx.currentTime + 0.2);
      break;
    case 'click':
      oscillator.frequency.setValueAtTime(800, audioCtx.currentTime);
      gainNode.gain.setValueAtTime(0.1, audioCtx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.05);
      oscillator.start(audioCtx.currentTime);
      oscillator.stop(audioCtx.currentTime + 0.05);
      break;
    case 'milestone':
      // Fanfare
      [523.25, 659.25, 783.99, 1046.50].forEach((freq, i) => {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.frequency.setValueAtTime(freq, audioCtx.currentTime + i * 0.15);
        gain.gain.setValueAtTime(0.2, audioCtx.currentTime + i * 0.15);
        gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + i * 0.15 + 0.3);
        osc.start(audioCtx.currentTime + i * 0.15);
        osc.stop(audioCtx.currentTime + i * 0.15 + 0.3);
      });
      break;
    case 'newword':
      oscillator.frequency.setValueAtTime(440, audioCtx.currentTime);
      oscillator.frequency.setValueAtTime(550, audioCtx.currentTime + 0.1);
      gainNode.gain.setValueAtTime(0.2, audioCtx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.2);
      oscillator.start(audioCtx.currentTime);
      oscillator.stop(audioCtx.currentTime + 0.2);
      break;
  }
}

function updateSoundIcon() {
  document.getElementById('soundIcon').textContent = stats.soundEnabled ? '🔊' : '🔇';
  
  const toggle = document.getElementById('soundEffectsToggle');
  if (toggle) toggle.classList.toggle('active', stats.soundEnabled);
}

// ============================================
// XP & Leveling System
// ============================================

function addXP(amount, reason) {
  stats.xp += amount;
  checkLevelUp();
  saveStats();
  
  // Show XP popup
  showXPGain(amount, reason);
}

function checkLevelUp() {
  const newLevel = LEVELS.slice().reverse().find(l => stats.xp >= l.minXP);
  if (newLevel && newLevel.level > stats.level) {
    stats.level = newLevel.level;
    showLevelUp(newLevel);
    playSound('milestone');
    launchConfetti();
  }
}

function showXPGain(amount, reason) {
  const popup = document.createElement('div');
  popup.className = 'xp-popup';
  popup.innerHTML = `+${amount} XP <small>${reason || ''}</small>`;
  document.body.appendChild(popup);
  
  setTimeout(() => popup.classList.add('show'), 10);
  setTimeout(() => {
    popup.classList.remove('show');
    setTimeout(() => popup.remove(), 300);
  }, 2000);
}

function showLevelUp(level) {
  showMilestone(`🎉 Level ${level.level}: ${level.name}!`);
}

function getLevelProgress() {
  const current = LEVELS.slice().reverse().find(l => stats.xp >= l.minXP);
  const next = LEVELS.find(l => l.level === current.level + 1);
  if (!next) return 100;
  
  const progress = ((stats.xp - current.minXP) / (next.minXP - current.minXP)) * 100;
  return Math.min(100, progress);
}

function getCurrentLevel() {
  return LEVELS.slice().reverse().find(l => stats.xp >= l.minXP) || LEVELS[0];
}

// ============================================
// Achievement System
// ============================================

function checkAchievements(context = {}) {
  const newAchievements = [];
  
  ACHIEVEMENTS.forEach(achievement => {
    if (stats.achievements.includes(achievement.id)) return;
    
    let earned = false;
    
    switch(achievement.id) {
      case 'first_word': earned = stats.wordsLearned >= 1; break;
      case 'streak_7': earned = stats.currentStreak >= 7; break;
      case 'streak_30': earned = stats.currentStreak >= 30; break;
      case 'streak_100': earned = stats.currentStreak >= 100; break;
      case 'words_10': earned = stats.wordsLearned >= 10; break;
      case 'words_50': earned = stats.wordsLearned >= 50; break;
      case 'words_100': earned = stats.wordsLearned >= 100; break;
      case 'words_200': earned = stats.wordsLearned >= 200; break;
      case 'early_bird': earned = context.earlyBird; break;
      case 'night_owl': earned = context.nightOwl; break;
      case 'perfect_quiz': earned = context.perfectQuiz; break;
      case 'quiz_streak_5': earned = context.quizStreak >= 5; break;
      case 'speed_demon': earned = context.perfectSpeed; break;
      case 'all_categories':
        const learnedCats = new Set(stats.learnedWords.map(w => {
          const word = VOCABULARY.find(v => v.word.toLowerCase() === w);
          return word?.category;
        }).filter(c => c));
        earned = learnedCats.size >= 8;
        break;
      case 'mastery_5':
        const mastered5 = Object.values(stats.wordMastery).filter(m => m.level >= 5).length;
        earned = mastered5 >= 5;
        break;
      case 'mastery_20':
        const mastered20 = Object.values(stats.wordMastery).filter(m => m.level >= 5).length;
        earned = mastered20 >= 20;
        break;
      case 'recovery': earned = context.streakRecovered; break;
      case 'goal_week': earned = context.goalWeek; break;
      case 'challenge_all': earned = context.allChallenges; break;
      case 'notes_10':
        earned = Object.keys(stats.personalNotes).length >= 10;
        break;
    }
    
    if (earned) {
      stats.achievements.push(achievement.id);
      newAchievements.push(achievement);
      addXP(achievement.xp, achievement.name);
    }
  });
  
  if (newAchievements.length > 0) {
    showAchievementUnlock(newAchievements[0]);
    saveStats();
  }
}

function showAchievementUnlock(achievement) {
  const modal = document.createElement('div');
  modal.className = 'achievement-modal';
  modal.innerHTML = `
    <div class="achievement-content">
      <div class="achievement-icon">${achievement.icon}</div>
      <div class="achievement-title">Achievement Unlocked!</div>
      <div class="achievement-name">${achievement.name}</div>
      <div class="achievement-desc">${achievement.desc}</div>
      <div class="achievement-xp">+${achievement.xp} XP</div>
    </div>
  `;
  document.body.appendChild(modal);
  
  playSound('milestone');
  setTimeout(() => modal.classList.add('show'), 10);
  setTimeout(() => {
    modal.classList.remove('show');
    setTimeout(() => modal.remove(), 300);
  }, 3000);
}

// ============================================
// Streak Recovery System
// ============================================

function checkStreakRecovery() {
  const today = getTodayString();
  const yesterday = getYesterdayString();
  
  // If they missed yesterday and have missed days to recover
  if (stats.lastPracticeDate && stats.lastPracticeDate !== today && stats.lastPracticeDate !== yesterday) {
    // Calculate missed days
    const lastDate = new Date(stats.lastPracticeDate);
    const todayDate = new Date(today);
    const diffDays = Math.floor((todayDate - lastDate) / (1000 * 60 * 60 * 24));
    
    if (diffDays > 1 && stats.currentStreak > 0) {
      stats.missedDays = diffDays - 1;
      return true;
    }
  }
  return false;
}

function attemptStreakRecovery() {
  if (stats.missedDays > 0 && stats.todayWordsLearned >= 2) {
    stats.missedDays--;
    if (stats.missedDays === 0) {
      // Streak recovered!
      checkAchievements({ streakRecovered: true });
      showMilestone('🔄 Streak Recovered!');
    }
    saveStats();
    return true;
  }
  return false;
}

function getYesterdayString() {
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  return yesterday.toISOString().split('T')[0];
}

// ============================================
// Daily Goal System
// ============================================

function checkDailyGoal() {
  const today = getTodayString();
  
  // Reset daily counter if new day
  if (stats.lastGoalDate !== today) {
    stats.todayWordsLearned = 0;
    stats.lastGoalDate = today;
  }
}

function incrementDailyProgress() {
  checkDailyGoal();
  stats.todayWordsLearned++;
  
  if (stats.todayWordsLearned >= stats.dailyGoal) {
    showMilestone(`🎯 Daily goal reached! (${stats.dailyGoal}/${stats.dailyGoal})`);
    addXP(15, 'Daily Goal');
  }
  
  // Check for streak recovery
  attemptStreakRecovery();
  
  saveStats();
  updateGoalDisplay();
}

function updateGoalDisplay() {
  const goalEl = document.getElementById('goalProgress');
  if (goalEl) {
    goalEl.textContent = `${Math.min(stats.todayWordsLearned, stats.dailyGoal)}/${stats.dailyGoal}`;
  }
  
  const goalBar = document.getElementById('goalBar');
  if (goalBar) {
    const percent = Math.min(100, (stats.todayWordsLearned / stats.dailyGoal) * 100);
    goalBar.style.width = `${percent}%`;
  }
}

// ============================================
// Daily Challenges
// ============================================

function getDailyChallenge() {
  const today = getTodayString();
  // Use date as seed for consistent daily challenge
  const seed = today.split('-').reduce((a, b) => a + parseInt(b), 0);
  return DAILY_CHALLENGES[seed % DAILY_CHALLENGES.length];
}

function checkDailyChallenge(context = {}) {
  const today = getTodayString();
  if (stats.dailyChallengeCompleted === today) return;
  
  const challenge = getDailyChallenge();
  if (challenge.check(stats, context)) {
    stats.dailyChallengeCompleted = today;
    addXP(challenge.xp, 'Daily Challenge');
    showMilestone(`✅ Challenge Complete: ${challenge.desc}`);
    saveStats();
  }
}

// ============================================
// Pronunciation Speed Control
// ============================================

function speakWord() {
  if (!currentWord) return;
  
  playSound('click');
  
  const utterance = new SpeechSynthesisUtterance(currentWord.word);
  utterance.rate = stats.pronunciationSpeed || 0.8;
  utterance.pitch = 1;
  
  const voices = speechSynthesis.getVoices();
  const englishVoice = voices.find(v => v.lang.startsWith('en-'));
  if (englishVoice) utterance.voice = englishVoice;
  
  speechSynthesis.speak(utterance);
}

function setPronunciationSpeed(speed) {
  stats.pronunciationSpeed = speed;
  saveStats();
  
  document.querySelectorAll('[data-speed]').forEach(btn => {
    btn.classList.toggle('active', parseFloat(btn.dataset.speed) === speed);
  });
}

// ============================================
// Collections (Named Favorites)
// ============================================

function getCollections() {
  return stats.collections || { favorites: [] };
}

function createCollection(name) {
  if (!stats.collections) stats.collections = { favorites: [] };
  if (!stats.collections[name]) {
    stats.collections[name] = [];
    saveStats();
    return true;
  }
  return false;
}

function addToCollection(collectionName, word) {
  if (!stats.collections[collectionName]) return false;
  if (!stats.collections[collectionName].includes(word.toLowerCase())) {
    stats.collections[collectionName].push(word.toLowerCase());
    saveStats();
    return true;
  }
  return false;
}

function removeFromCollection(collectionName, word) {
  if (!stats.collections[collectionName]) return false;
  const index = stats.collections[collectionName].indexOf(word.toLowerCase());
  if (index > -1) {
    stats.collections[collectionName].splice(index, 1);
    saveStats();
    return true;
  }
  return false;
}

function deleteCollection(name) {
  if (name === 'favorites') return false; // Can't delete default
  if (stats.collections[name]) {
    delete stats.collections[name];
    saveStats();
    return true;
  }
  return false;
}

// ============================================
// Smart Word Selection
// ============================================

function getSmartWord() {
  // Priority: Due for review > Struggling words > Random new
  
  // Check spaced repetition due words
  const today = getTodayString();
  const dueWords = stats.spacedRepetition.filter(item => item.nextReview <= today);
  if (dueWords.length > 0) {
    const dueWord = dueWords[0].word;
    const found = VOCABULARY.find(w => w.word.toLowerCase() === dueWord);
    if (found) return { word: found, reason: 'Review due' };
  }
  
  // Check struggling words (low mastery, seen multiple times)
  const strugglingWords = Object.entries(stats.wordMastery)
    .filter(([word, data]) => data.level < 3 && data.correctCount > 0)
    .sort((a, b) => a[1].level - b[1].level);
  
  if (strugglingWords.length > 0 && Math.random() < 0.3) {
    const word = strugglingWords[0][0];
    const found = VOCABULARY.find(w => w.word.toLowerCase() === word);
    if (found) return { word: found, reason: 'Needs practice' };
  }
  
  // Default: Random new word
  return { word: null, reason: 'New word' };
}

// ============================================
// Import/Export Custom Words & Data
// ============================================

function exportAllData() {
  const data = {
    version: '3.0',
    exportDate: new Date().toISOString(),
    stats: stats,
    customWords: stats.customWords || []
  };
  
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  
  const a = document.createElement('a');
  a.href = url;
  a.download = `word-of-the-day-backup-${getTodayString()}.json`;
  a.click();
  
  URL.revokeObjectURL(url);
  playSound('success');
  showFeedback('Data exported!', 'success');
}

function importData(file) {
  const reader = new FileReader();
  reader.onload = async (e) => {
    try {
      const data = JSON.parse(e.target.result);
      
      if (data.stats) {
        // Merge imported stats with current
        stats = { ...stats, ...data.stats };
        await saveStats();
        showFeedback('Data imported successfully!', 'success');
        updateUI();
      }
      
      if (data.customWords && data.customWords.length > 0) {
        stats.customWords = [...(stats.customWords || []), ...data.customWords];
        await saveStats();
        showFeedback(`${data.customWords.length} custom words imported!`, 'success');
      }
    } catch (err) {
      showFeedback('Invalid file format', 'error');
    }
  };
  reader.readAsText(file);
}

function importCustomWords(csvText) {
  // Expected format: word,partOfSpeech,definition,example
  const lines = csvText.trim().split('\n');
  const words = [];
  
  lines.forEach((line, i) => {
    if (i === 0 && line.toLowerCase().includes('word')) return; // Skip header
    
    const parts = line.split(',').map(p => p.trim().replace(/^"|"$/g, ''));
    if (parts.length >= 3) {
      words.push({
        word: parts[0],
        partOfSpeech: parts[1] || 'noun',
        definition: parts[2],
        example: parts[3] || `The word ${parts[0]} is useful.`,
        examples: [parts[3] || `The word ${parts[0]} is useful.`],
        etymology: 'Custom word',
        synonyms: [],
        antonyms: [],
        difficulty: 2,
        category: 'custom',
        isCustom: true
      });
    }
  });
  
  if (words.length > 0) {
    stats.customWords = [...(stats.customWords || []), ...words];
    saveStats();
    showFeedback(`${words.length} custom words added!`, 'success');
  }
  
  return words;
}

// ============================================
// Analytics
// ============================================

function getAnalytics() {
  // Words by category
  const categoryCount = {};
  stats.learnedWords.forEach(word => {
    const found = VOCABULARY.find(w => w.word.toLowerCase() === word);
    const cat = found?.category || 'unknown';
    categoryCount[cat] = (categoryCount[cat] || 0) + 1;
  });
  
  // Words by difficulty
  const difficultyCount = { 1: 0, 2: 0, 3: 0, 4: 0 };
  stats.learnedWords.forEach(word => {
    const found = VOCABULARY.find(w => w.word.toLowerCase() === word);
    const diff = found?.difficulty || 2;
    difficultyCount[diff]++;
  });
  
  // Quiz performance
  const quizAvg = stats.quizHistory?.length > 0 
    ? stats.quizHistory.reduce((a, q) => a + (q.score / q.total), 0) / stats.quizHistory.length * 100
    : 0;
  
  // Most difficult words (lowest mastery with attempts)
  const difficult = Object.entries(stats.wordMastery)
    .filter(([_, data]) => data.correctCount > 0 && data.level < 3)
    .sort((a, b) => a[1].level - b[1].level)
    .slice(0, 5)
    .map(([word]) => word);
  
  // Learning velocity (words per week)
  const weekAgo = new Date();
  weekAgo.setDate(weekAgo.getDate() - 7);
  const weekAgoStr = weekAgo.toISOString().split('T')[0];
  const thisWeekWords = Object.entries(stats.learningHistory)
    .filter(([date]) => date >= weekAgoStr)
    .reduce((sum, [_, words]) => sum + words.length, 0);
  
  return {
    totalWords: stats.wordsLearned,
    categoryCount,
    difficultyCount,
    quizAverage: Math.round(quizAvg),
    difficultWords: difficult,
    weeklyVelocity: thisWeekWords,
    totalXP: stats.xp,
    level: getCurrentLevel(),
    achievementsUnlocked: stats.achievements.length,
    totalAchievements: ACHIEVEMENTS.length
  };
}

// ============================================
// Word Relationships
// ============================================

function getRelatedWords(word) {
  const related = [];
  const wordData = VOCABULARY.find(w => w.word.toLowerCase() === word.toLowerCase());
  if (!wordData) return related;
  
  // Find words with matching synonyms/antonyms
  VOCABULARY.forEach(w => {
    if (w.word.toLowerCase() === word.toLowerCase()) return;
    
    const isSynonym = wordData.synonyms?.some(s => 
      w.word.toLowerCase() === s.toLowerCase() ||
      w.synonyms?.includes(s)
    );
    
    const isAntonym = wordData.antonyms?.some(a => 
      w.word.toLowerCase() === a.toLowerCase() ||
      w.antonyms?.includes(a)
    );
    
    const sameCategory = w.category === wordData.category;
    
    if (isSynonym) related.push({ word: w.word, relation: 'synonym' });
    else if (isAntonym) related.push({ word: w.word, relation: 'antonym' });
    else if (sameCategory && related.length < 6) related.push({ word: w.word, relation: 'category' });
  });
  
  return related.slice(0, 8);
}

// ============================================
// Did You Know Facts
// ============================================

function getWordFact(word) {
  const facts = [];
  const wordData = VOCABULARY.find(w => w.word.toLowerCase() === word.toLowerCase());
  if (!wordData) return null;
  
  // Add interesting facts based on word properties
  if (wordData.etymology?.includes('Greek')) {
    facts.push('📜 This word has Greek origins');
  } else if (wordData.etymology?.includes('Latin')) {
    facts.push('📜 This word has Latin origins');
  }
  
  if (wordData.difficulty === 3) {
    facts.push('📚 This is a GRE-level word');
  } else if (wordData.difficulty === 4) {
    facts.push('🎭 This is a rare/obscure word');
  }
  
  if (wordData.word.length > 10) {
    facts.push(`📏 ${wordData.word.length} letters long`);
  }
  
  // Category-specific facts
  const categoryFacts = {
    literature: '📖 Often found in literary works',
    philosophy: '💭 A philosophical term',
    science: '🔬 Used in scientific contexts',
    law: '⚖️ Common in legal documents',
    medicine: '🏥 Medical terminology',
    business: '💼 Business jargon',
    arts: '🎨 Arts and culture term'
  };
  
  if (categoryFacts[wordData.category]) {
    facts.push(categoryFacts[wordData.category]);
  }
  
  return facts.length > 0 ? facts[Math.floor(Math.random() * facts.length)] : null;
}

// ============================================
// Confetti
// ============================================

function launchConfetti() {
  const canvas = document.getElementById('confettiCanvas');
  const ctx = canvas.getContext('2d');
  canvas.width = 380;
  canvas.height = 600;
  canvas.style.display = 'block';
  
  const particles = [];
  const colors = ['#0ea5e9', '#3b82f6', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981'];
  
  for (let i = 0; i < 100; i++) {
    particles.push({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height - canvas.height,
      r: Math.random() * 6 + 2,
      d: Math.random() * 100,
      color: colors[Math.floor(Math.random() * colors.length)],
      tilt: Math.floor(Math.random() * 10) - 10,
      tiltAngle: 0,
      tiltAngleIncrement: Math.random() * 0.07 + 0.05
    });
  }
  
  let animationFrame;
  function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    let allDone = true;
    particles.forEach(p => {
      if (p.y < canvas.height) allDone = false;
      
      ctx.beginPath();
      ctx.lineWidth = p.r;
      ctx.strokeStyle = p.color;
      ctx.moveTo(p.x + p.tilt + p.r, p.y);
      ctx.lineTo(p.x + p.tilt, p.y + p.tilt + p.r);
      ctx.stroke();
      
      p.tiltAngle += p.tiltAngleIncrement;
      p.y += (Math.cos(p.d) + 3 + p.r / 2) / 2;
      p.x += Math.sin(p.d);
      p.tilt = Math.sin(p.tiltAngle) * 15;
    });
    
    if (allDone) {
      cancelAnimationFrame(animationFrame);
      canvas.style.display = 'none';
      return;
    }
    
    animationFrame = requestAnimationFrame(draw);
  }
  
  draw();
  
  setTimeout(() => {
    cancelAnimationFrame(animationFrame);
    canvas.style.display = 'none';
  }, 4000);
}

// ============================================
// Streak Freeze
// ============================================

function checkStreakFreeze() {
  const today = new Date();
  const currentWeek = getWeekNumber(today);
  
  // Reset freeze if new week
  if (stats.streakFreezeWeek !== currentWeek) {
    stats.streakFreezeWeek = currentWeek;
    stats.streakFreezeUsed = null;
    saveStats();
  }
  
  // Check if freeze was used recently
  if (stats.streakFreezeUsed) {
    const freezeDate = new Date(stats.streakFreezeUsed);
    if (isYesterday(stats.streakFreezeUsed)) {
      document.getElementById('freezeBanner').classList.remove('hidden');
      document.getElementById('freezesLeft').textContent = '0';
    }
  }
  
  updateFreezeCount();
}

function getWeekNumber(d) {
  d = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7));
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  return Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
}

function useStreakFreeze() {
  if (stats.streakFreezeUsed) return false;
  
  stats.streakFreezeUsed = getTodayString();
  saveStats();
  return true;
}

function updateFreezeCount() {
  const freezeCount = stats.streakFreezeUsed ? 0 : 1;
  const el = document.getElementById('freezeCount');
  if (el) el.textContent = freezeCount;
}

// ============================================
// Word Mastery
// ============================================

function getMasteryLevel(word) {
  const mastery = stats.wordMastery[word.toLowerCase()];
  if (!mastery) return 0;
  return mastery.level || 0;
}

function updateMastery(word, correct) {
  const key = word.toLowerCase();
  if (!stats.wordMastery[key]) {
    stats.wordMastery[key] = { level: 1, correctCount: 0, lastSeen: getTodayString() };
  }
  
  const m = stats.wordMastery[key];
  m.lastSeen = getTodayString();
  
  if (correct) {
    m.correctCount++;
    // Level up based on correct answers
    if (m.correctCount >= 1 && m.level < 1) m.level = 1; // Seen
    if (m.correctCount >= 2 && m.level < 2) m.level = 2; // Used
    if (m.correctCount >= 4 && m.level < 3) m.level = 3; // Quizzed
    if (m.correctCount >= 7 && m.level < 4) m.level = 4; // Retained
    if (m.correctCount >= 10 && m.level < 5) m.level = 5; // Mastered
  }
  
  saveStats();
}

function getMasteryStars(level) {
  const filled = '★'.repeat(level);
  const empty = '☆'.repeat(5 - level);
  return filled + empty;
}

function updateMasteryDisplay() {
  if (!currentWord) return;
  const level = getMasteryLevel(currentWord.word);
  document.getElementById('masteryStars').textContent = getMasteryStars(level);
  document.getElementById('masteryBadge').setAttribute('data-level', level);
}

// ============================================
// Onboarding
// ============================================

function showOnboarding() {
  document.getElementById('onboarding').classList.remove('hidden');
}

function hideOnboarding() {
  document.getElementById('onboarding').classList.add('hidden');
  stats.isFirstTime = false;
  saveStats();
  playSound('success');
}

// ============================================
// Data Persistence
// ============================================

async function loadStats() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['vocabStats'], (result) => {
      if (result.vocabStats) {
        stats = { ...stats, ...result.vocabStats };
      }
      resolve();
    });
  });
}

async function saveStats() {
  return new Promise((resolve) => {
    chrome.storage.local.set({ vocabStats: stats }, resolve);
  });
}

// ============================================
// Word Management
// ============================================

function getTodayString() {
  return new Date().toISOString().split('T')[0];
}

async function checkLookupWord() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['lookupWord'], (result) => {
      if (result.lookupWord) {
        const word = result.lookupWord.toLowerCase();
        const found = VOCABULARY.find(w => w.word.toLowerCase() === word);
        if (found) {
          currentWord = found;
          chrome.storage.local.remove(['lookupWord']);
        }
      }
      resolve();
    });
  });
}

async function loadOrSetDailyWord() {
  if (currentWord) return;
  
  return new Promise((resolve) => {
    chrome.storage.local.get(['dailyWord', 'dailyWordDate'], (result) => {
      const today = getTodayString();
      
      if (result.dailyWord && result.dailyWordDate === today) {
        currentWord = result.dailyWord;
      } else {
        setNewWord();
        chrome.storage.local.set({ dailyWord: currentWord, dailyWordDate: today });
      }
      resolve();
    });
  });
}

function setNewWord() {
  const availableWords = VOCABULARY.filter(w => 
    w.difficulty <= stats.difficulty &&
    stats.enabledCategories.includes(w.category) &&
    !stats.learnedWords.includes(w.word.toLowerCase()) &&
    !stats.skippedWords.includes(w.word.toLowerCase())
  );
  
  const wordPool = availableWords.length > 0 ? availableWords : 
    VOCABULARY.filter(w => w.difficulty <= stats.difficulty && stats.enabledCategories.includes(w.category));
  
  const randomIndex = Math.floor(Math.random() * wordPool.length);
  currentWord = wordPool[randomIndex] || VOCABULARY[0];
}

async function getNewWord() {
  playSound('newword');
  
  // Animate card flip
  const card = document.getElementById('wordCard');
  card.classList.add('flip-out');
  
  setTimeout(async () => {
    setNewWord();
    const today = getTodayString();
    
    await new Promise((resolve) => {
      chrome.storage.local.set({ dailyWord: currentWord, dailyWordDate: today }, resolve);
    });
    
    addToHistory(currentWord.word, 'viewed');
    document.getElementById('userSentence').value = '';
    document.getElementById('feedback').className = 'feedback';
    document.getElementById('hintSection').classList.add('hidden');
    
    updateWordDisplay();
    card.classList.remove('flip-out');
    card.classList.add('flip-in');
    setTimeout(() => card.classList.remove('flip-in'), 300);
  }, 150);
}

async function skipWord() {
  playSound('click');
  if (currentWord && !stats.skippedWords.includes(currentWord.word.toLowerCase())) {
    stats.skippedWords.push(currentWord.word.toLowerCase());
    addToHistory(currentWord.word, 'skipped');
    await saveStats();
  }
  await getNewWord();
}

// ============================================
// Word History
// ============================================

function addToHistory(word, action) {
  stats.wordHistory.unshift({
    word: word,
    date: new Date().toISOString(),
    action: action
  });
  
  // Keep last 100 entries
  if (stats.wordHistory.length > 100) {
    stats.wordHistory = stats.wordHistory.slice(0, 100);
  }
  
  saveStats();
}

function showHistory() {
  showView('history');
  renderHistory();
}

function renderHistory() {
  const list = document.getElementById('historyList');
  list.innerHTML = '';
  
  if (stats.wordHistory.length === 0) {
    list.innerHTML = '<p class="empty-state">No history yet. Start learning!</p>';
    return;
  }
  
  // Group by date
  const grouped = {};
  stats.wordHistory.forEach(item => {
    const date = item.date.split('T')[0];
    if (!grouped[date]) grouped[date] = [];
    grouped[date].push(item);
  });
  
  Object.entries(grouped).forEach(([date, items]) => {
    const dateHeader = document.createElement('div');
    dateHeader.className = 'history-date';
    dateHeader.textContent = formatDate(date);
    list.appendChild(dateHeader);
    
    items.forEach(item => {
      const el = document.createElement('div');
      el.className = 'history-item';
      
      const actionIcon = item.action === 'learned' ? '✓' : 
                         item.action === 'skipped' ? '⏭️' : '👁️';
      
      el.innerHTML = `
        <span class="history-icon">${actionIcon}</span>
        <span class="history-word">${item.word}</span>
        <span class="history-time">${formatTime(item.date)}</span>
      `;
      
      el.addEventListener('click', () => {
        const found = VOCABULARY.find(w => w.word.toLowerCase() === item.word.toLowerCase());
        if (found) {
          currentWord = found;
          showView('main');
          updateWordDisplay();
        }
      });
      
      list.appendChild(el);
    });
  });
}

function formatDate(dateStr) {
  const date = new Date(dateStr);
  const today = new Date();
  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);
  
  if (dateStr === today.toISOString().split('T')[0]) return 'Today';
  if (dateStr === yesterday.toISOString().split('T')[0]) return 'Yesterday';
  
  return date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
}

function formatTime(isoStr) {
  const date = new Date(isoStr);
  return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
}

// ============================================
// Hints
// ============================================

function showHint() {
  if (!currentWord) return;
  
  playSound('click');
  const hints = getHints(currentWord);
  const hintSection = document.getElementById('hintSection');
  const hintText = document.getElementById('hintText');
  
  hintText.textContent = hints[Math.floor(Math.random() * hints.length)];
  hintSection.classList.remove('hidden');
}

function getHints(word) {
  const templates = [
    `Try starting with: "The ${word.word.toLowerCase()} nature of..."`,
    `How about: "It was ${word.partOfSpeech === 'adjective' ? 'an ' + word.word.toLowerCase() : word.word.toLowerCase()}..."`,
    `Consider: "Despite being ${word.word.toLowerCase()}..."`,
    `You could say: "The ${word.word.toLowerCase()} ${word.partOfSpeech === 'noun' ? 'was' : 'situation'}..."`,
    `Think about a time when something was ${word.definition.split(' ').slice(0, 3).join(' ')}...`
  ];
  
  return templates;
}

// ============================================
// Personal Notes
// ============================================

function toggleNotes() {
  const notesInput = document.getElementById('notesInput');
  const isHidden = notesInput.classList.contains('hidden');
  
  notesInput.classList.toggle('hidden');
  
  if (isHidden && currentWord) {
    const note = stats.personalNotes[currentWord.word.toLowerCase()] || '';
    document.getElementById('personalNotes').value = note;
  }
  
  playSound('click');
}

function saveNote() {
  if (!currentWord) return;
  
  const note = document.getElementById('personalNotes').value.trim();
  const key = currentWord.word.toLowerCase();
  
  if (note) {
    stats.personalNotes[key] = note;
    document.getElementById('notesIndicator').classList.remove('hidden');
    
    // Check daily challenge and achievements
    checkDailyChallenge({ addedNote: true });
    checkAchievements();
  } else {
    delete stats.personalNotes[key];
    document.getElementById('notesIndicator').classList.add('hidden');
  }
  
  saveStats();
  playSound('success');
  showFeedback('Note saved!', 'success');
}

function updateNotesIndicator() {
  if (!currentWord) return;
  const hasNote = stats.personalNotes[currentWord.word.toLowerCase()];
  document.getElementById('notesIndicator').classList.toggle('hidden', !hasNote);
}

// ============================================
// Challenge Mode
// ============================================

function showChallenge() {
  showView('challenge');
  document.getElementById('challengeSelect').classList.remove('hidden');
  document.getElementById('challengeGame').classList.add('hidden');
  document.getElementById('challengeResult').classList.add('hidden');
}

function startChallenge(mode) {
  playSound('click');
  
  const learnedWordObjects = VOCABULARY.filter(w => 
    stats.learnedWords.includes(w.word.toLowerCase())
  );
  
  if (learnedWordObjects.length < 5) {
    showFeedback('Learn more words first!', 'error');
    return;
  }
  
  challengeState = {
    mode: mode,
    questions: [],
    current: 0,
    score: 0,
    startTime: Date.now(),
    timer: null
  };
  
  const shuffled = learnedWordObjects.sort(() => Math.random() - 0.5).slice(0, 10);
  
  challengeState.questions = shuffled.map(word => ({
    word: word.word,
    definition: word.definition,
    example: word.example
  }));
  
  document.getElementById('challengeSelect').classList.add('hidden');
  document.getElementById('challengeGame').classList.remove('hidden');
  
  if (mode === 'speed') {
    startChallengeTimer();
  }
  
  showChallengeQuestion();
}

function startChallengeTimer() {
  let seconds = 60;
  const timerEl = document.getElementById('challengeTimer');
  timerEl.textContent = seconds;
  timerEl.classList.add('active');
  
  challengeState.timer = setInterval(() => {
    seconds--;
    timerEl.textContent = seconds;
    
    if (seconds <= 10) timerEl.classList.add('warning');
    
    if (seconds <= 0) {
      endChallenge();
    }
  }, 1000);
}

function showChallengeQuestion() {
  const q = challengeState.questions[challengeState.current];
  const mode = challengeState.mode;
  
  document.getElementById('challengeProgress').textContent = 
    `${challengeState.current + 1}/${challengeState.questions.length}`;
  document.getElementById('challengeBarFill').style.width = 
    `${((challengeState.current + 1) / challengeState.questions.length) * 100}%`;
  
  const questionEl = document.getElementById('challengeQuestion');
  const inputEl = document.getElementById('challengeInput');
  const optionsEl = document.getElementById('challengeOptionsGrid');
  
  inputEl.classList.add('hidden');
  optionsEl.classList.add('hidden');
  optionsEl.innerHTML = '';
  document.getElementById('challengeFeedback').textContent = '';
  
  if (mode === 'speed') {
    questionEl.textContent = `What does "${q.word}" mean?`;
    
    // Generate options
    const options = [q.definition];
    const otherWords = VOCABULARY.filter(w => w.word !== q.word);
    while (options.length < 4) {
      const rand = otherWords[Math.floor(Math.random() * otherWords.length)];
      if (!options.includes(rand.definition)) options.push(rand.definition);
    }
    options.sort(() => Math.random() - 0.5);
    
    optionsEl.classList.remove('hidden');
    options.forEach(opt => {
      const btn = document.createElement('button');
      btn.className = 'challenge-opt-btn';
      btn.textContent = opt;
      btn.onclick = () => checkChallengeAnswer(opt, q.definition);
      optionsEl.appendChild(btn);
    });
    
  } else if (mode === 'reverse') {
    questionEl.innerHTML = `<span class="challenge-def">${q.definition}</span><br><small>Type the word:</small>`;
    inputEl.classList.remove('hidden');
    inputEl.value = '';
    inputEl.focus();
    
  } else if (mode === 'fillblank') {
    const sentence = q.example.replace(new RegExp(q.word, 'gi'), '_____');
    questionEl.innerHTML = `<span class="challenge-sentence">${sentence}</span><br><small>Fill in the blank:</small>`;
    inputEl.classList.remove('hidden');
    inputEl.value = '';
    inputEl.focus();
  }
}

function checkChallengeAnswer(answer, correct) {
  const mode = challengeState.mode;
  const q = challengeState.questions[challengeState.current];
  let isCorrect = false;
  
  if (mode === 'speed') {
    isCorrect = answer === correct;
  } else {
    isCorrect = answer.toLowerCase().trim() === q.word.toLowerCase();
  }
  
  const feedbackEl = document.getElementById('challengeFeedback');
  
  if (isCorrect) {
    challengeState.score++;
    feedbackEl.textContent = '✓ Correct!';
    feedbackEl.className = 'challenge-feedback correct';
    playSound('success');
  } else {
    feedbackEl.textContent = `✗ It was: ${mode === 'speed' ? 'see above' : q.word}`;
    feedbackEl.className = 'challenge-feedback wrong';
    playSound('error');
  }
  
  // Disable buttons
  document.querySelectorAll('.challenge-opt-btn').forEach(btn => {
    btn.disabled = true;
    if (btn.textContent === correct) btn.classList.add('correct');
    else if (btn.textContent === answer && !isCorrect) btn.classList.add('wrong');
  });
  
  setTimeout(() => {
    challengeState.current++;
    if (challengeState.current < challengeState.questions.length) {
      showChallengeQuestion();
    } else {
      endChallenge();
    }
  }, 1000);
}

function endChallenge() {
  if (challengeState.timer) {
    clearInterval(challengeState.timer);
    document.getElementById('challengeTimer').classList.remove('active', 'warning');
  }
  
  const elapsed = Math.round((Date.now() - challengeState.startTime) / 1000);
  
  document.getElementById('challengeGame').classList.add('hidden');
  document.getElementById('challengeResult').classList.remove('hidden');
  
  document.getElementById('challengeScore').textContent = 
    `${challengeState.score}/${challengeState.questions.length}`;
  document.getElementById('challengeTime').textContent = `Time: ${elapsed}s`;
  
  const percent = challengeState.score / challengeState.questions.length;
  const messages = ['Keep practicing!', 'Good effort!', 'Great job!', 'Perfect!'];
  document.getElementById('challengeMessage').textContent = 
    messages[Math.min(3, Math.floor(percent * 4))];
  
  // Add XP for challenge
  addXP(challengeState.score * 4, 'Challenge');
  
  // Track completed challenge types
  if (!stats.completedChallenges) stats.completedChallenges = [];
  if (!stats.completedChallenges.includes(challengeState.mode)) {
    stats.completedChallenges.push(challengeState.mode);
  }
  
  // Check achievements
  const isPerfect = percent === 1;
  const isPerfectSpeed = isPerfect && challengeState.mode === 'speed';
  const allChallenges = stats.completedChallenges.length >= 3;
  
  checkAchievements({
    perfectSpeed: isPerfectSpeed,
    allChallenges: allChallenges
  });
  
  // Check daily challenge
  if (challengeState.mode === 'speed') {
    checkDailyChallenge({ speedChallenge: true });
  }
  
  saveStats();
  
  if (percent >= 0.8) {
    playSound('milestone');
    launchConfetti();
  }
}

// ============================================
// UI Updates
// ============================================

function updateDate() {
  const options = { weekday: 'long', month: 'short', day: 'numeric' };
  document.getElementById('todayDate').textContent = new Date().toLocaleDateString('en-US', options);
}

function updateUI() {
  updateWordDisplay();
  updateStats();
  updateMasteryDisplay();
  updateNotesIndicator();
}

function updateWordDisplay() {
  if (!currentWord) return;
  
  document.getElementById('currentWord').textContent = currentWord.word;
  document.getElementById('partOfSpeech').textContent = currentWord.partOfSpeech;
  document.getElementById('definition').textContent = currentWord.definition;
  
  // Badges
  const diffLabels = { 1: 'Everyday', 2: 'SAT', 3: 'GRE', 4: 'Obscure' };
  document.getElementById('difficultyBadge').textContent = diffLabels[currentWord.difficulty] || 'SAT';
  document.getElementById('categoryBadge').textContent = currentWord.category || 'general';
  
  // Etymology
  const etymSection = document.getElementById('etymologySection');
  if (currentWord.etymology) {
    etymSection.style.display = 'flex';
    document.getElementById('etymology').textContent = currentWord.etymology;
  } else {
    etymSection.style.display = 'none';
  }
  
  // Pronunciation
  document.getElementById('pronunciation').textContent = generatePronunciation(currentWord.word);
  
  // Examples (multiple)
  const examplesList = document.getElementById('examplesList');
  examplesList.innerHTML = '';
  
  const examples = currentWord.examples || [currentWord.example];
  examples.forEach((ex, i) => {
    const p = document.createElement('p');
    p.className = 'example-item';
    p.textContent = ex;
    if (i > 0) p.classList.add('secondary');
    examplesList.appendChild(p);
  });
  
  // Synonyms & Antonyms
  const synonymsEl = document.getElementById('synonyms');
  const antonymsEl = document.getElementById('antonyms');
  synonymsEl.innerHTML = '';
  antonymsEl.innerHTML = '';
  
  (currentWord.synonyms || []).slice(0, 3).forEach(syn => {
    const span = document.createElement('span');
    span.textContent = syn;
    synonymsEl.appendChild(span);
  });
  
  (currentWord.antonyms || []).slice(0, 3).forEach(ant => {
    const span = document.createElement('span');
    span.textContent = ant;
    antonymsEl.appendChild(span);
  });
  
  updateMasteryDisplay();
  updateNotesIndicator();
}

function generatePronunciation(word) {
  return '/' + word.toLowerCase()
    .replace(/ph/g, 'f')
    .replace(/tion/g, 'shən')
    .replace(/sion/g, 'zhən')
    .replace(/ous$/g, 'əs')
    + '/';
}

function updateStats() {
  document.getElementById('streakCount').textContent = stats.currentStreak;
  document.getElementById('wordsLearned').textContent = stats.wordsLearned;
  document.getElementById('bestStreak').textContent = stats.bestStreak;
}

// ============================================
// Sentence Checking
// ============================================

function checkSentence() {
  const sentence = document.getElementById('userSentence').value.trim();
  
  if (!sentence) {
    showFeedback('Write a sentence first!', 'error');
    playSound('error');
    return;
  }
  
  if (!currentWord) {
    showFeedback('No word loaded.', 'error');
    return;
  }
  
  const wordLower = currentWord.word.toLowerCase();
  const sentenceLower = sentence.toLowerCase();
  const wordRegex = new RegExp(`\\b${escapeRegex(wordLower)}\\w*\\b`, 'i');
  
  if (wordRegex.test(sentenceLower)) {
    handleSuccess();
  } else {
    showFeedback(`Use "${currentWord.word}" in your sentence.`, 'error');
    playSound('error');
  }
}

function escapeRegex(string) {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

async function handleSuccess() {
  const today = getTodayString();
  const wordLower = currentWord.word.toLowerCase();
  const hour = new Date().getHours();
  
  // Check for time-based achievements
  const achievementContext = {
    earlyBird: hour < 8,
    nightOwl: hour >= 22
  };
  
  if (!stats.learnedWords.includes(wordLower)) {
    stats.learnedWords.push(wordLower);
    stats.wordsLearned = stats.learnedWords.length;
    
    addToSpacedRepetition(wordLower);
    addToHistory(currentWord.word, 'learned');
    
    if (!stats.learningHistory[today]) {
      stats.learningHistory[today] = [];
    }
    if (!stats.learningHistory[today].includes(wordLower)) {
      stats.learningHistory[today].push(wordLower);
    }
    
    checkMilestone(stats.wordsLearned);
    
    // Add XP for learning new word
    addXP(10, 'New word');
    
    // Increment daily goal progress
    incrementDailyProgress();
  }
  
  // Add XP for using word in sentence
  addXP(5, 'Sentence');
  
  updateMastery(currentWord.word, true);
  
  // Check achievements
  checkAchievements(achievementContext);
  
  // Check daily challenge
  checkDailyChallenge();
  
  // Update streak
  if (stats.lastPracticeDate !== today) {
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().split('T')[0];
    
    if (stats.lastPracticeDate === yesterdayStr) {
      stats.currentStreak++;
    } else if (!stats.lastPracticeDate) {
      stats.currentStreak = 1;
    } else {
      // Check for streak freeze
      if (!stats.streakFreezeUsed && stats.currentStreak > 0) {
        useStreakFreeze();
        document.getElementById('freezeBanner').classList.remove('hidden');
        document.getElementById('freezesLeft').textContent = '0';
      } else {
        stats.currentStreak = 1;
      }
    }
    
    if (stats.currentStreak > stats.bestStreak) {
      stats.bestStreak = stats.currentStreak;
    }
    
    stats.lastPracticeDate = today;
  }
  
  // Update level display
  updateLevelDisplay();
  
  await saveStats();
  updateStats();
  
  playSound('success');
  showFeedback(`🎉 Nice! You've got "${currentWord.word}"!`, 'success');
}

function isYesterday(dateString) {
  if (!dateString) return false;
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  return dateString === yesterday.toISOString().split('T')[0];
}

function showFeedback(message, type) {
  const feedback = document.getElementById('feedback');
  feedback.textContent = message;
  feedback.className = `feedback ${type} show`;
}

// ============================================
// Spaced Repetition
// ============================================

function addToSpacedRepetition(word) {
  const today = new Date();
  const nextReview = new Date(today);
  nextReview.setDate(nextReview.getDate() + 1);
  
  stats.spacedRepetition.push({
    word: word,
    nextReview: nextReview.toISOString().split('T')[0],
    interval: 1,
    easeFactor: 2.5
  });
}

function checkSpacedRepetition() {
  const today = getTodayString();
  const dueWords = stats.spacedRepetition.filter(item => item.nextReview <= today);
  
  if (dueWords.length > 0) {
    const srBanner = document.getElementById('srBanner');
    const srWord = document.getElementById('srWord');
    srWord.textContent = dueWords[0].word;
    srBanner.classList.remove('hidden');
  }
}

async function reviewSpacedWord() {
  const today = getTodayString();
  const dueWords = stats.spacedRepetition.filter(item => item.nextReview <= today);
  
  if (dueWords.length > 0) {
    const wordToReview = dueWords[0].word;
    const foundWord = VOCABULARY.find(w => w.word.toLowerCase() === wordToReview);
    
    if (foundWord) {
      currentWord = foundWord;
      updateWordDisplay();
      document.getElementById('srBanner').classList.add('hidden');
      
      const item = stats.spacedRepetition.find(i => i.word === wordToReview);
      if (item) {
        item.interval = Math.round(item.interval * item.easeFactor);
        const nextDate = new Date();
        nextDate.setDate(nextDate.getDate() + item.interval);
        item.nextReview = nextDate.toISOString().split('T')[0];
      }
      
      await saveStats();
    }
  }
}

// ============================================
// Milestones
// ============================================

function checkMilestone(count) {
  const milestones = [10, 25, 50, 100, 150, 200, 250, 300, 365, 500];
  if (milestones.includes(count)) {
    showMilestone(`🎉 ${count} words learned!`);
    playSound('milestone');
    launchConfetti();
  }
}

function showMilestone(text) {
  const toast = document.getElementById('milestoneToast');
  document.getElementById('milestoneText').textContent = text;
  toast.classList.remove('hidden');
  toast.classList.add('show');
  
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.classList.add('hidden'), 300);
  }, 3000);
}

// ============================================
// Audio
// ============================================

function speakWord() {
  if (!currentWord) return;
  
  playSound('click');
  
  const utterance = new SpeechSynthesisUtterance(currentWord.word);
  utterance.rate = 0.8;
  utterance.pitch = 1;
  
  const voices = speechSynthesis.getVoices();
  const englishVoice = voices.find(v => v.lang.startsWith('en-'));
  if (englishVoice) utterance.voice = englishVoice;
  
  speechSynthesis.speak(utterance);
}

// ============================================
// Theme
// ============================================

function applyTheme(theme) {
  document.body.setAttribute('data-theme', theme);
  stats.theme = theme;
  
  document.querySelectorAll('.theme-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.theme === theme);
  });
}

function toggleTheme() {
  const themes = ['light', 'dark', 'sepia'];
  const currentIndex = themes.indexOf(stats.theme);
  const nextTheme = themes[(currentIndex + 1) % themes.length];
  applyTheme(nextTheme);
  saveStats();
  playSound('click');
}

// ============================================
// Quiz & Word Bank (existing)
// ============================================

function startQuiz() {
  const learnedWordObjects = VOCABULARY.filter(w => 
    stats.learnedWords.includes(w.word.toLowerCase())
  );
  
  if (learnedWordObjects.length < 4) {
    showFeedback('Learn more words to take the quiz!', 'error');
    return;
  }
  
  playSound('click');
  
  const shuffled = learnedWordObjects.sort(() => Math.random() - 0.5);
  const quizWords = shuffled.slice(0, Math.min(7, shuffled.length));
  
  quizState = {
    questions: quizWords.map(word => ({
      word: word.word,
      correct: word.definition,
      options: generateQuizOptions(word, VOCABULARY)
    })),
    current: 0,
    score: 0
  };
  
  showView('quiz');
  showQuizQuestion();
}

function generateQuizOptions(correctWord, allWords) {
  const options = [correctWord.definition];
  const otherWords = allWords.filter(w => w.word !== correctWord.word);
  
  while (options.length < 4 && otherWords.length > 0) {
    const randomIndex = Math.floor(Math.random() * otherWords.length);
    const randomWord = otherWords.splice(randomIndex, 1)[0];
    if (!options.includes(randomWord.definition)) {
      options.push(randomWord.definition);
    }
  }
  
  return options.sort(() => Math.random() - 0.5);
}

function showQuizQuestion() {
  const q = quizState.questions[quizState.current];
  
  document.getElementById('quizProgress').textContent = `${quizState.current + 1}/${quizState.questions.length}`;
  document.getElementById('quizQuestion').textContent = `What does "${q.word}" mean?`;
  
  const optionsEl = document.getElementById('quizOptions');
  optionsEl.innerHTML = '';
  
  q.options.forEach(option => {
    const btn = document.createElement('button');
    btn.className = 'quiz-option';
    btn.textContent = option;
    btn.onclick = () => selectQuizOption(btn, option, q.correct, q.word);
    optionsEl.appendChild(btn);
  });
  
  document.getElementById('quizResult').classList.add('hidden');
  document.querySelector('.quiz-content').classList.remove('hidden');
}

function selectQuizOption(btn, selected, correct, word) {
  document.querySelectorAll('.quiz-option').forEach(b => {
    b.disabled = true;
    if (b.textContent === correct) b.classList.add('correct');
  });
  
  if (selected === correct) {
    quizState.score++;
    updateMastery(word, true);
    playSound('success');
  } else {
    btn.classList.add('wrong');
    playSound('error');
  }
  
  setTimeout(() => {
    quizState.current++;
    if (quizState.current < quizState.questions.length) {
      showQuizQuestion();
    } else {
      showQuizResult();
    }
  }, 1000);
}

function showQuizResult() {
  document.querySelector('.quiz-content').classList.add('hidden');
  document.getElementById('quizResult').classList.remove('hidden');
  
  document.getElementById('quizScore').textContent = `${quizState.score}/${quizState.questions.length}`;
  
  const percent = quizState.score / quizState.questions.length;
  const messages = ['Keep practicing! 📚', 'Good effort! 💪', 'Great job! 👏', 'Perfect! 🎯'];
  document.getElementById('quizMessage').textContent = messages[Math.min(3, Math.floor(percent * 4))];
  
  // Track quiz history
  if (!stats.quizHistory) stats.quizHistory = [];
  stats.quizHistory.push({
    date: getTodayString(),
    score: quizState.score,
    total: quizState.questions.length
  });
  
  // Add XP for quiz
  addXP(quizState.score * 3, 'Quiz');
  
  // Check for perfect quiz
  const isPerfect = percent === 1;
  if (isPerfect) {
    playSound('milestone');
    launchConfetti();
    
    // Count consecutive perfect quizzes
    const recentPerfect = stats.quizHistory.slice(-5).filter(q => q.score === q.total).length;
    
    checkAchievements({ 
      perfectQuiz: true,
      quizStreak: recentPerfect
    });
    
    checkDailyChallenge({ perfectQuiz: true });
  }
  
  saveStats();
}

function showWordBank(filter = 'all', category = null) {
  showView('bank');
  renderWordBank(filter, category);
  generateCategoryFilters();
  
  document.querySelectorAll('.bank-filters .filter-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.filter === filter);
  });
}

function renderWordBank(filter, category = null) {
  let words = VOCABULARY.filter(w => stats.learnedWords.includes(w.word.toLowerCase()));
  
  if (filter === 'favorites') {
    words = words.filter(w => stats.favorites.includes(w.word.toLowerCase()));
  } else if (filter === 'mastered') {
    words = words.filter(w => getMasteryLevel(w.word) >= 5);
  }
  
  if (category) {
    words = words.filter(w => w.category === category);
  }
  
  const listEl = document.getElementById('bankList');
  const emptyEl = document.getElementById('bankEmpty');
  
  if (words.length === 0) {
    listEl.classList.add('hidden');
    emptyEl.classList.remove('hidden');
    return;
  }
  
  emptyEl.classList.add('hidden');
  listEl.classList.remove('hidden');
  listEl.innerHTML = '';
  
  words.forEach(word => {
    const isFav = stats.favorites.includes(word.word.toLowerCase());
    const mastery = getMasteryLevel(word.word);
    
    const item = document.createElement('div');
    item.className = 'bank-item';
    item.innerHTML = `
      <div class="bank-item-main">
        <div class="bank-item-word">${word.word}</div>
        <div class="bank-item-def">${word.definition.slice(0, 50)}...</div>
        <div class="bank-item-mastery">${getMasteryStars(mastery)}</div>
      </div>
      <button class="bank-item-fav ${isFav ? 'active' : ''}" data-word="${word.word.toLowerCase()}">⭐</button>
    `;
    
    listEl.appendChild(item);
  });
  
  document.querySelectorAll('.bank-item-fav').forEach(btn => {
    btn.onclick = () => toggleFavorite(btn.dataset.word, btn);
  });
}

function generateCategoryFilters() {
  const container = document.getElementById('categoryFilters');
  if (!container) return;
  
  container.innerHTML = '';
  
  const learnedCategories = [...new Set(
    VOCABULARY.filter(w => stats.learnedWords.includes(w.word.toLowerCase()))
      .map(w => w.category)
  )];
  
  learnedCategories.forEach(cat => {
    const btn = document.createElement('button');
    btn.className = 'cat-filter-btn';
    btn.textContent = cat;
    btn.onclick = () => showWordBank('all', cat);
    container.appendChild(btn);
  });
}

async function toggleFavorite(word, btn) {
  const index = stats.favorites.indexOf(word);
  if (index > -1) {
    stats.favorites.splice(index, 1);
    btn.classList.remove('active');
  } else {
    stats.favorites.push(word);
    btn.classList.add('active');
  }
  playSound('click');
  await saveStats();
}

function exportWords() {
  const words = VOCABULARY.filter(w => stats.learnedWords.includes(w.word.toLowerCase()));
  
  let csv = 'Word,Part of Speech,Definition,Category,Example,Mastery\n';
  words.forEach(w => {
    const mastery = getMasteryLevel(w.word);
    csv += `"${w.word}","${w.partOfSpeech}","${w.definition}","${w.category}","${w.example}","${mastery}/5"\n`;
  });
  
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  
  const a = document.createElement('a');
  a.href = url;
  a.download = 'vocabulary-words.csv';
  a.click();
  
  URL.revokeObjectURL(url);
  playSound('success');
}

// ============================================
// Calendar, Settings, Share (existing)
// ============================================

function showCalendar() {
  showView('calendar');
  renderCalendar();
}

function renderCalendar() {
  const grid = document.getElementById('calendarGrid');
  grid.innerHTML = '';
  
  const today = new Date();
  const startDate = new Date(today);
  startDate.setDate(startDate.getDate() - 90);
  
  let thisMonthCount = 0;
  const currentMonth = today.getMonth();
  
  for (let i = 0; i < 91; i++) {
    const date = new Date(startDate);
    date.setDate(date.getDate() + i);
    const dateStr = date.toISOString().split('T')[0];
    
    const wordsLearned = stats.learningHistory[dateStr]?.length || 0;
    
    if (date.getMonth() === currentMonth) {
      thisMonthCount += wordsLearned;
    }
    
    const cell = document.createElement('div');
    cell.className = 'calendar-cell';
    cell.title = `${dateStr}: ${wordsLearned} words`;
    
    if (wordsLearned === 0) cell.classList.add('empty');
    else if (wordsLearned === 1) cell.classList.add('light');
    else if (wordsLearned <= 3) cell.classList.add('medium');
    else cell.classList.add('full');
    
    grid.appendChild(cell);
  }
  
  document.getElementById('calTotalWords').textContent = stats.wordsLearned;
  document.getElementById('calThisMonth').textContent = thisMonthCount;
}

function showSettings() {
  showView('settings');
  
  // Update daily goal buttons
  document.querySelectorAll('.goal-btn').forEach(btn => {
    btn.classList.toggle('active', parseInt(btn.dataset.goal) === stats.dailyGoal);
  });
  
  // Update difficulty buttons
  document.querySelectorAll('[data-difficulty]').forEach(btn => {
    btn.classList.toggle('active', parseInt(btn.dataset.difficulty) === stats.difficulty);
  });
  
  // Update pronunciation speed buttons
  document.querySelectorAll('.speed-btn').forEach(btn => {
    btn.classList.toggle('active', parseFloat(btn.dataset.speed) === stats.pronunciationSpeed);
  });
  
  // Update theme buttons
  document.querySelectorAll('.theme-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.theme === stats.theme);
  });
  
  // Update toggles
  const notifToggle = document.getElementById('notificationToggle');
  if (notifToggle) notifToggle.classList.toggle('active', stats.notificationsEnabled);
  
  const soundToggle = document.getElementById('soundEffectsToggle');
  if (soundToggle) soundToggle.classList.toggle('active', stats.soundEnabled);
  
  // Generate category toggles
  generateCategoryToggles();
  
  // Update custom word count
  updateCustomWordCount();
  
  updateFreezeCount();
}

function generateCategoryToggles() {
  const container = document.getElementById('categoryToggles');
  if (!container) {
    console.log('categoryToggles container not found');
    return;
  }
  
  container.innerHTML = '';
  
  if (typeof VOCABULARY === 'undefined' || !VOCABULARY.length) {
    console.log('VOCABULARY not available');
    return;
  }
  
  const categories = [...new Set(VOCABULARY.map(w => w.category).filter(c => c))].sort();
  console.log('Categories found:', categories);
  
  categories.forEach(cat => {
    const btn = document.createElement('button');
    btn.className = 'setting-btn cat-toggle';
    btn.textContent = cat;
    btn.dataset.category = cat;
    btn.classList.toggle('active', stats.enabledCategories.includes(cat));
    btn.onclick = () => toggleCategory(cat, btn);
    container.appendChild(btn);
  });
}

async function toggleCategory(category, btn) {
  const index = stats.enabledCategories.indexOf(category);
  if (index > -1) {
    if (stats.enabledCategories.length > 1) {
      stats.enabledCategories.splice(index, 1);
      btn.classList.remove('active');
    }
  } else {
    stats.enabledCategories.push(category);
    btn.classList.add('active');
  }
  playSound('click');
  await saveStats();
}

async function setDifficulty(level) {
  stats.difficulty = level;
  playSound('click');
  await saveStats();
  
  document.querySelectorAll('[data-difficulty]').forEach(btn => {
    btn.classList.toggle('active', parseInt(btn.dataset.difficulty) === level);
  });
}

async function toggleNotifications() {
  stats.notificationsEnabled = !stats.notificationsEnabled;
  
  const toggle = document.getElementById('notificationToggle');
  toggle.classList.toggle('active', stats.notificationsEnabled);
  
  if (stats.notificationsEnabled) {
    const permission = await Notification.requestPermission();
    if (permission !== 'granted') {
      stats.notificationsEnabled = false;
      toggle.classList.remove('active');
      showFeedback('Notification permission denied', 'error');
    }
  }
  
  playSound('click');
  await saveStats();
}

async function toggleSoundEffects() {
  stats.soundEnabled = !stats.soundEnabled;
  
  const toggle = document.getElementById('soundEffectsToggle');
  toggle.classList.toggle('active', stats.soundEnabled);
  
  updateSoundIcon();
  if (stats.soundEnabled) playSound('click');
  await saveStats();
}

async function resetProgress() {
  if (confirm('Reset all progress? This cannot be undone.')) {
    stats = {
      currentStreak: 0,
      bestStreak: 0,
      wordsLearned: 0,
      learnedWords: [],
      skippedWords: [],
      favorites: [],
      lastPracticeDate: null,
      difficulty: stats.difficulty,
      theme: stats.theme,
      notificationsEnabled: false,
      soundEnabled: stats.soundEnabled,
      isFirstTime: false,
      spacedRepetition: [],
      learningHistory: {},
      enabledCategories: stats.enabledCategories,
      wordMastery: {},
      personalNotes: {},
      wordHistory: [],
      streakFreezeUsed: null,
      streakFreezeWeek: null
    };
    await saveStats();
    await getNewWord();
    updateStats();
    showView('main');
    playSound('click');
  }
}

function showShareModal() {
  if (!currentWord) return;
  
  document.getElementById('shareCardWord').textContent = currentWord.word;
  document.getElementById('shareCardPos').textContent = currentWord.partOfSpeech;
  document.getElementById('shareCardDef').textContent = currentWord.definition;
  
  document.getElementById('shareModal').classList.remove('hidden');
  playSound('click');
}

function hideShareModal() {
  document.getElementById('shareModal').classList.add('hidden');
}

async function copyShareCard() {
  const text = `📚 Word of the Day: ${currentWord.word}\n${currentWord.partOfSpeech} — ${currentWord.definition}`;
  navigator.clipboard.writeText(text);
  showFeedback('Copied to clipboard!', 'success');
  playSound('success');
  hideShareModal();
}

function downloadShareCard() {
  const canvas = document.createElement('canvas');
  canvas.width = 400;
  canvas.height = 250;
  const ctx = canvas.getContext('2d');
  
  ctx.fillStyle = stats.theme === 'dark' ? '#1e1e24' : '#ffffff';
  ctx.fillRect(0, 0, 400, 250);
  
  ctx.fillStyle = '#0ea5e9';
  ctx.fillRect(0, 0, 400, 4);
  
  ctx.fillStyle = stats.theme === 'dark' ? '#f4f4f6' : '#1a1a18';
  ctx.font = '12px sans-serif';
  ctx.fillText('Word of the Day', 24, 35);
  
  ctx.font = 'bold 32px Georgia';
  ctx.fillText(currentWord.word, 24, 90);
  
  ctx.font = 'italic 14px Georgia';
  ctx.fillStyle = '#0ea5e9';
  ctx.fillText(currentWord.partOfSpeech, 24, 115);
  
  ctx.font = '16px sans-serif';
  ctx.fillStyle = stats.theme === 'dark' ? '#a0a0aa' : '#6b6860';
  
  const words = currentWord.definition.split(' ');
  let line = '';
  let y = 150;
  words.forEach(word => {
    const testLine = line + word + ' ';
    if (ctx.measureText(testLine).width > 350) {
      ctx.fillText(line, 24, y);
      line = word + ' ';
      y += 24;
    } else {
      line = testLine;
    }
  });
  ctx.fillText(line, 24, y);
  
  ctx.font = '11px sans-serif';
  ctx.fillStyle = '#a09a92';
  ctx.fillText('wordoftheday.app', 24, 230);
  
  const link = document.createElement('a');
  link.download = `${currentWord.word}-word-of-the-day.png`;
  link.href = canvas.toDataURL();
  link.click();
  
  playSound('success');
  hideShareModal();
}

function copyTemplate() {
  if (!currentWord) return;
  
  const template = `The word "${currentWord.word}" means "${currentWord.definition}". `;
  navigator.clipboard.writeText(template);
  playSound('click');
  
  const btn = document.getElementById('copyBtn');
  btn.style.color = 'var(--success)';
  setTimeout(() => btn.style.color = '', 1000);
}

// ============================================
// View Management
// ============================================

function showView(view) {
  const views = ['main', 'history', 'challenge', 'calendar', 'quiz', 'bank', 'settings', 'achievements', 'analytics'];
  views.forEach(v => {
    const el = document.getElementById(`${v}View`);
    if (el) el.classList.toggle('hidden', v !== view);
  });
}

// ============================================
// Event Listeners
// ============================================

function setupEventListeners() {
  // Onboarding
  document.getElementById('onboardingDone').addEventListener('click', hideOnboarding);
  
  // Header
  document.getElementById('themeToggle').addEventListener('click', toggleTheme);
  document.getElementById('settingsBtn').addEventListener('click', showSettings);
  document.getElementById('achievementsBtn')?.addEventListener('click', showAchievements);
  document.getElementById('soundToggle').addEventListener('click', () => {
    stats.soundEnabled = !stats.soundEnabled;
    updateSoundIcon();
    if (stats.soundEnabled) playSound('click');
    saveStats();
  });
  
  // Spaced repetition
  document.getElementById('srReviewBtn')?.addEventListener('click', reviewSpacedWord);
  
  // Word actions
  document.getElementById('audioBtn').addEventListener('click', speakWord);
  document.getElementById('skipBtn').addEventListener('click', skipWord);
  document.getElementById('notesToggle').addEventListener('click', toggleNotes);
  document.getElementById('notesSave').addEventListener('click', saveNote);
  
  // Practice
  document.getElementById('checkBtn').addEventListener('click', checkSentence);
  document.getElementById('copyBtn').addEventListener('click', copyTemplate);
  document.getElementById('shareBtn').addEventListener('click', showShareModal);
  document.getElementById('hintBtn').addEventListener('click', () => {
    showHint();
    checkDailyChallenge({ usedHint: true });
  });
  document.getElementById('userSentence').addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      checkSentence();
    }
  });
  
  // Footer buttons
  document.getElementById('historyBtn').addEventListener('click', showHistory);
  document.getElementById('challengeBtn').addEventListener('click', showChallenge);
  document.getElementById('quizBtn').addEventListener('click', startQuiz);
  document.getElementById('bankBtn').addEventListener('click', () => showWordBank('all'));
  document.getElementById('analyticsBtn')?.addEventListener('click', showAnalytics);
  
  // History view
  document.getElementById('historyBackBtn').addEventListener('click', () => showView('main'));
  
  // Challenge view
  document.getElementById('challengeBackBtn').addEventListener('click', () => {
    if (challengeState.timer) clearInterval(challengeState.timer);
    showView('main');
  });
  document.getElementById('challengeDoneBtn').addEventListener('click', () => showView('main'));
  document.querySelectorAll('.challenge-option').forEach(btn => {
    btn.addEventListener('click', () => startChallenge(btn.dataset.mode));
  });
  document.getElementById('challengeInput').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      const q = challengeState.questions[challengeState.current];
      checkChallengeAnswer(e.target.value, q.word);
    }
  });
  
  // Achievements view
  document.getElementById('achievementsBackBtn')?.addEventListener('click', () => showView('main'));
  
  // Analytics view
  document.getElementById('analyticsBackBtn')?.addEventListener('click', () => showView('main'));
  document.getElementById('shareProgressBtn')?.addEventListener('click', showProgressCard);
  
  // Progress card modal
  document.getElementById('progressClose')?.addEventListener('click', hideProgressCard);
  document.getElementById('copyProgressCard')?.addEventListener('click', () => {
    const text = `📚 My Vocabulary Journey\n${stats.wordsLearned} words • ${stats.currentStreak} day streak • Level ${getCurrentLevel().level}\nwordoftheday.app`;
    navigator.clipboard.writeText(text);
    showFeedback('Copied!', 'success');
    hideProgressCard();
  });
  document.getElementById('downloadProgressCard')?.addEventListener('click', downloadProgressCard);
  
  // Quiz view
  document.getElementById('quizBackBtn').addEventListener('click', () => showView('main'));
  document.getElementById('quizDoneBtn').addEventListener('click', () => showView('main'));
  
  // Bank view
  document.getElementById('bankBackBtn').addEventListener('click', () => showView('main'));
  document.getElementById('exportBtn').addEventListener('click', exportWords);
  
  document.querySelectorAll('.bank-filters .filter-btn').forEach(btn => {
    btn.addEventListener('click', () => showWordBank(btn.dataset.filter));
  });
  
  // Settings view
  document.getElementById('settingsBackBtn').addEventListener('click', () => showView('main'));
  document.getElementById('resetBtn').addEventListener('click', resetProgress);
  document.getElementById('notificationToggle').addEventListener('click', toggleNotifications);
  document.getElementById('soundEffectsToggle').addEventListener('click', toggleSoundEffects);
  
  // Daily goal buttons
  document.querySelectorAll('.goal-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      stats.dailyGoal = parseInt(btn.dataset.goal);
      saveStats();
      updateGoalDisplay();
      document.querySelectorAll('.goal-btn').forEach(b => 
        b.classList.toggle('active', b.dataset.goal === btn.dataset.goal)
      );
      playSound('click');
    });
  });
  
  // Pronunciation speed buttons
  document.querySelectorAll('.speed-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      setPronunciationSpeed(parseFloat(btn.dataset.speed));
      playSound('click');
    });
  });
  
  document.querySelectorAll('[data-difficulty]').forEach(btn => {
    btn.addEventListener('click', () => setDifficulty(parseInt(btn.dataset.difficulty)));
  });
  
  document.querySelectorAll('.theme-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      applyTheme(btn.dataset.theme);
      playSound('click');
      saveStats();
    });
  });
  
  // Data export/import
  document.getElementById('exportDataBtn')?.addEventListener('click', exportAllData);
  document.getElementById('importDataInput')?.addEventListener('change', (e) => {
    if (e.target.files[0]) {
      importData(e.target.files[0]);
    }
  });
  
  // Custom words import
  document.getElementById('importWordsInput')?.addEventListener('change', (e) => {
    if (e.target.files[0]) {
      const reader = new FileReader();
      reader.onload = (ev) => {
        importCustomWords(ev.target.result);
        updateCustomWordCount();
      };
      reader.readAsText(e.target.files[0]);
    }
  });
  
  // Share modal
  document.getElementById('shareClose').addEventListener('click', hideShareModal);
  document.getElementById('copyShareCard').addEventListener('click', copyShareCard);
  document.getElementById('downloadShareCard').addEventListener('click', downloadShareCard);
}

function updateCustomWordCount() {
  const el = document.getElementById('customWordCount');
  if (el) el.textContent = stats.customWords?.length || 0;
}

function setupKeyboardShortcuts() {
  document.addEventListener('keydown', (e) => {
    if (e.target.tagName === 'TEXTAREA' || e.target.tagName === 'INPUT') return;
    
    switch(e.key.toLowerCase()) {
      case 'n': getNewWord(); break;
      case 'l': speakWord(); break;
      case 's': skipWord(); break;
      case 't': toggleTheme(); break;
      case 'q': startQuiz(); break;
      case 'b': showWordBank('all'); break;
      case 'h': showHistory(); break;
      case 'c': showCalendar(); break;
      case 'escape': 
        showView('main'); 
        hideShareModal(); 
        break;
    }
  });
}

// ============================================
// Display Updates
// ============================================

function updateLevelDisplay() {
  const level = getCurrentLevel();
  const progress = getLevelProgress();
  
  const badge = document.getElementById('levelBadge');
  if (badge) badge.textContent = `Lv.${level.level}`;
  
  const fill = document.getElementById('xpFill');
  if (fill) fill.style.width = `${progress}%`;
}

function updateDailyChallengeDisplay() {
  const challenge = getDailyChallenge();
  const today = getTodayString();
  const completed = stats.dailyChallengeCompleted === today;
  
  const textEl = document.getElementById('challengeText');
  const sectionEl = document.getElementById('dailyChallenge');
  
  if (textEl) {
    textEl.textContent = completed ? '✅ Challenge complete!' : challenge.desc;
  }
  if (sectionEl) {
    sectionEl.classList.toggle('completed', completed);
  }
}

function updateWordDisplay() {
  if (!currentWord) return;
  
  document.getElementById('currentWord').textContent = currentWord.word;
  document.getElementById('partOfSpeech').textContent = currentWord.partOfSpeech;
  document.getElementById('definition').textContent = currentWord.definition;
  
  // Badges
  const diffLabels = { 1: 'Everyday', 2: 'SAT', 3: 'GRE', 4: 'Obscure' };
  document.getElementById('difficultyBadge').textContent = diffLabels[currentWord.difficulty] || 'SAT';
  document.getElementById('categoryBadge').textContent = currentWord.category || 'general';
  
  // Etymology
  const etymSection = document.getElementById('etymologySection');
  if (currentWord.etymology) {
    etymSection.style.display = 'flex';
    document.getElementById('etymology').textContent = currentWord.etymology;
  } else {
    etymSection.style.display = 'none';
  }
  
  // Pronunciation
  document.getElementById('pronunciation').textContent = generatePronunciation(currentWord.word);
  
  // Examples (multiple)
  const examplesList = document.getElementById('examplesList');
  examplesList.innerHTML = '';
  
  const examples = currentWord.examples || [currentWord.example];
  examples.forEach((ex, i) => {
    const p = document.createElement('p');
    p.className = 'example-item';
    p.textContent = ex;
    if (i > 0) p.classList.add('secondary');
    examplesList.appendChild(p);
  });
  
  // Synonyms & Antonyms
  const synonymsEl = document.getElementById('synonyms');
  const antonymsEl = document.getElementById('antonyms');
  synonymsEl.innerHTML = '';
  antonymsEl.innerHTML = '';
  
  (currentWord.synonyms || []).slice(0, 3).forEach(syn => {
    const span = document.createElement('span');
    span.textContent = syn;
    synonymsEl.appendChild(span);
  });
  
  (currentWord.antonyms || []).slice(0, 3).forEach(ant => {
    const span = document.createElement('span');
    span.textContent = ant;
    antonymsEl.appendChild(span);
  });
  
  // Did You Know fact
  const factSection = document.getElementById('factSection');
  const factText = document.getElementById('factText');
  const fact = getWordFact(currentWord.word);
  if (fact && factSection && factText) {
    factSection.classList.remove('hidden');
    factText.textContent = fact;
  } else if (factSection) {
    factSection.classList.add('hidden');
  }
  
  // Related words
  const relatedSection = document.getElementById('relatedSection');
  const relatedWords = document.getElementById('relatedWords');
  if (relatedSection && relatedWords) {
    const related = getRelatedWords(currentWord.word)
      .filter(r => stats.learnedWords.includes(r.word.toLowerCase()));
    
    if (related.length > 0) {
      relatedSection.classList.remove('hidden');
      relatedWords.innerHTML = '';
      related.slice(0, 4).forEach(r => {
        const span = document.createElement('span');
        span.className = `related-tag ${r.relation}`;
        span.textContent = r.word;
        relatedWords.appendChild(span);
      });
    } else {
      relatedSection.classList.add('hidden');
    }
  }
  
  updateMasteryDisplay();
  updateNotesIndicator();
}

// ============================================
// Achievements View
// ============================================

function showAchievements() {
  showView('achievements');
  renderAchievements();
}

function renderAchievements() {
  const grid = document.getElementById('achievementsGrid');
  if (!grid) return;
  
  grid.innerHTML = '';
  
  const level = getCurrentLevel();
  const nextLevel = LEVELS.find(l => l.level === level.level + 1);
  
  // Update header
  const levelName = document.getElementById('levelName');
  const totalXP = document.getElementById('totalXP');
  const xpNext = document.getElementById('xpNext');
  const xpFillLarge = document.getElementById('xpFillLarge');
  const achievementsCount = document.getElementById('achievementsCount');
  
  if (levelName) levelName.textContent = level.name;
  if (totalXP) totalXP.textContent = `${stats.xp} XP`;
  if (xpNext) xpNext.textContent = nextLevel ? `${nextLevel.minXP - stats.xp} XP to ${nextLevel.name}` : 'Max level!';
  if (xpFillLarge) xpFillLarge.style.width = `${getLevelProgress()}%`;
  if (achievementsCount) achievementsCount.textContent = `${stats.achievements.length}/${ACHIEVEMENTS.length}`;
  
  ACHIEVEMENTS.forEach(achievement => {
    const unlocked = stats.achievements.includes(achievement.id);
    
    const card = document.createElement('div');
    card.className = `achievement-card ${unlocked ? 'unlocked' : 'locked'}`;
    card.innerHTML = `
      <span class="achievement-icon">${achievement.icon}</span>
      <div class="achievement-info">
        <span class="achievement-name">${achievement.name}</span>
        <span class="achievement-desc">${achievement.desc}</span>
        <span class="achievement-xp">+${achievement.xp} XP</span>
      </div>
      ${unlocked ? '<span class="achievement-check">✓</span>' : ''}
    `;
    
    grid.appendChild(card);
  });
}

// ============================================
// Analytics View
// ============================================

function showAnalytics() {
  showView('analytics');
  renderAnalytics();
}

function renderAnalytics() {
  const analytics = getAnalytics();
  
  // Summary stats
  const totalWords = document.getElementById('analyticsTotalWords');
  const weekly = document.getElementById('analyticsWeekly');
  const quizAvg = document.getElementById('analyticsQuizAvg');
  
  if (totalWords) totalWords.textContent = analytics.totalWords;
  if (weekly) weekly.textContent = analytics.weeklyVelocity;
  if (quizAvg) quizAvg.textContent = `${analytics.quizAverage}%`;
  
  // Category bars
  const categoryBars = document.getElementById('categoryBars');
  if (categoryBars) {
    categoryBars.innerHTML = '';
    const maxCat = Math.max(...Object.values(analytics.categoryCount), 1);
    
    Object.entries(analytics.categoryCount).forEach(([cat, count]) => {
      const bar = document.createElement('div');
      bar.className = 'analytics-bar';
      bar.innerHTML = `
        <span class="bar-label">${cat}</span>
        <div class="bar-track">
          <div class="bar-fill" style="width: ${(count / maxCat) * 100}%"></div>
        </div>
        <span class="bar-value">${count}</span>
      `;
      categoryBars.appendChild(bar);
    });
  }
  
  // Difficulty bars
  const difficultyBars = document.getElementById('difficultyBars');
  if (difficultyBars) {
    difficultyBars.innerHTML = '';
    const diffLabels = { 1: 'Everyday', 2: 'SAT', 3: 'GRE', 4: 'Obscure' };
    const maxDiff = Math.max(...Object.values(analytics.difficultyCount), 1);
    
    Object.entries(analytics.difficultyCount).forEach(([diff, count]) => {
      const bar = document.createElement('div');
      bar.className = 'analytics-bar';
      bar.innerHTML = `
        <span class="bar-label">${diffLabels[diff]}</span>
        <div class="bar-track">
          <div class="bar-fill" style="width: ${(count / maxDiff) * 100}%"></div>
        </div>
        <span class="bar-value">${count}</span>
      `;
      difficultyBars.appendChild(bar);
    });
  }
  
  // Difficult words
  const difficultWords = document.getElementById('difficultWords');
  if (difficultWords) {
    if (analytics.difficultWords.length > 0) {
      difficultWords.innerHTML = '';
      analytics.difficultWords.forEach(word => {
        const tag = document.createElement('span');
        tag.className = 'difficult-word-tag';
        tag.textContent = word;
        tag.onclick = () => {
          const found = VOCABULARY.find(w => w.word.toLowerCase() === word.toLowerCase());
          if (found) {
            currentWord = found;
            showView('main');
            updateWordDisplay();
          }
        };
        difficultWords.appendChild(tag);
      });
    } else {
      difficultWords.innerHTML = '<p class="empty-state">No struggling words yet!</p>';
    }
  }
}

// ============================================
// Progress Card
// ============================================

function showProgressCard() {
  const modal = document.getElementById('progressModal');
  if (!modal) return;
  
  // Update card data
  const pcWords = document.getElementById('pcWords');
  const pcStreak = document.getElementById('pcStreak');
  const pcLevel = document.getElementById('pcLevel');
  const pcAchievements = document.getElementById('pcAchievements');
  
  if (pcWords) pcWords.textContent = stats.wordsLearned;
  if (pcStreak) pcStreak.textContent = stats.currentStreak;
  if (pcLevel) pcLevel.textContent = getCurrentLevel().level;
  
  if (pcAchievements) {
    pcAchievements.innerHTML = '';
    // Show last 3 achievements
    const recentAchievements = stats.achievements.slice(-3).map(id => 
      ACHIEVEMENTS.find(a => a.id === id)
    ).filter(a => a);
    
    recentAchievements.forEach(a => {
      const span = document.createElement('span');
      span.className = 'pc-achievement';
      span.textContent = a.icon;
      span.title = a.name;
      pcAchievements.appendChild(span);
    });
  }
  
  modal.classList.remove('hidden');
  playSound('click');
}

function hideProgressCard() {
  const modal = document.getElementById('progressModal');
  if (modal) modal.classList.add('hidden');
}

function downloadProgressCard() {
  const canvas = document.createElement('canvas');
  canvas.width = 400;
  canvas.height = 300;
  const ctx = canvas.getContext('2d');
  
  // Background
  ctx.fillStyle = stats.theme === 'dark' ? '#1e1e24' : '#ffffff';
  ctx.fillRect(0, 0, 400, 300);
  
  // Header
  ctx.fillStyle = '#0ea5e9';
  ctx.fillRect(0, 0, 400, 6);
  
  ctx.fillStyle = stats.theme === 'dark' ? '#f4f4f6' : '#1a1a18';
  ctx.font = '14px sans-serif';
  ctx.fillText('My Vocabulary Journey', 24, 40);
  
  // Stats
  ctx.font = 'bold 36px Georgia';
  ctx.fillText(stats.wordsLearned.toString(), 40, 100);
  ctx.fillText(stats.currentStreak.toString(), 160, 100);
  ctx.fillText(getCurrentLevel().level.toString(), 280, 100);
  
  ctx.font = '12px sans-serif';
  ctx.fillStyle = stats.theme === 'dark' ? '#a0a0aa' : '#6b6860';
  ctx.fillText('Words', 40, 120);
  ctx.fillText('Streak', 160, 120);
  ctx.fillText('Level', 280, 120);
  
  // Level name
  ctx.font = '16px sans-serif';
  ctx.fillStyle = '#0ea5e9';
  ctx.fillText(getCurrentLevel().name, 24, 170);
  
  // XP
  ctx.fillStyle = stats.theme === 'dark' ? '#a0a0aa' : '#6b6860';
  ctx.font = '12px sans-serif';
  ctx.fillText(`${stats.xp} XP`, 24, 190);
  
  // Achievements
  const recentAchievements = stats.achievements.slice(-5).map(id => 
    ACHIEVEMENTS.find(a => a.id === id)
  ).filter(a => a);
  
  ctx.font = '24px sans-serif';
  recentAchievements.forEach((a, i) => {
    ctx.fillText(a.icon, 24 + i * 40, 240);
  });
  
  // Footer
  ctx.font = '11px sans-serif';
  ctx.fillStyle = '#a09a92';
  ctx.fillText('wordoftheday.app', 24, 280);
  
  const link = document.createElement('a');
  link.download = `vocabulary-progress-${getTodayString()}.png`;
  link.href = canvas.toDataURL();
  link.click();
  
  playSound('success');
  hideProgressCard();
}

// Load voices
speechSynthesis.onvoiceschanged = () => speechSynthesis.getVoices();
